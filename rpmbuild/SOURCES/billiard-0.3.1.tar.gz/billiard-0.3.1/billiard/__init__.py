"""Multiprocessing Pool Extensions"""
VERSION = (0, 3, 1)
__version__ = ".".join(map(str, VERSION))
__author__ = "Ask Solem"
__contact__ = "askh@opera.com"
__homepage__ = "http://github.com/ask/billiard"
__docformat__ = "restructuredtext"
