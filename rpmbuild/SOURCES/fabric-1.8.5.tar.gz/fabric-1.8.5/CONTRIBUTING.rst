Please see `contributing-guide.org <http://contributing-guide.org>`_ for
details on what we expect from contributors. Thanks!
