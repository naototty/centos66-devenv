import subsubmodule

def classic_task():
    pass
