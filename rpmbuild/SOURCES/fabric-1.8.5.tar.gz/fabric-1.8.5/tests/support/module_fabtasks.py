def hello():
    print("hello")


def world():
    print("world")
