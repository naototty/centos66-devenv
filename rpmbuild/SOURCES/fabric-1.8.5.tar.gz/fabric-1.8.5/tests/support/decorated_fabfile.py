from fabric.decorators import task

@task
def foo():
    pass

def bar():
    pass
