.. _signals:

.. currentmodule:: celery.signals

.. automodule:: celery.signals
