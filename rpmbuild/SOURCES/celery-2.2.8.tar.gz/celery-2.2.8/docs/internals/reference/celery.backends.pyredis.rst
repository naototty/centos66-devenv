==========================================
 celery.backends.pyredis
==========================================

.. contents::
    :local:
.. currentmodule:: celery.backends.pyredis

.. automodule:: celery.backends.pyredis
    :members:
    :undoc-members:
