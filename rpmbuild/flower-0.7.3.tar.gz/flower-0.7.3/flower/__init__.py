from __future__ import absolute_import

VERSION = (0, 7, 3)
__version__ = '.'.join(map(str, VERSION))

from .app import Flower  # noqa
